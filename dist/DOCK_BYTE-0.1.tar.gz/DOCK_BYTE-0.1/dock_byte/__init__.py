from .script import extract_text_from_pdf, ocr_pdf, extract_text_from_txt, chat_with_doc
